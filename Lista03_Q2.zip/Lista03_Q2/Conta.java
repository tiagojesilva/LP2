import java.util.ArrayList;

public class Conta
{
    private int mes;
    private int ano;
    private int contrato;
    private Ligacao listaVetor[];
    private ArrayList<Ligacao> listaArray;
    
    public Conta(int contrato, int mes, int ano)
    {
        this.contrato = contrato;
        this.mes = mes;
        this.ano = ano;
        
        this.listaVetor = new Ligacao[50];
        this.listaArray = new ArrayList<Ligacao>();
    }
    
        public void adicionarLigacaoVetor(Ligacao lig)
    {
        for (int i = 0 ; i < 50 ; i++)
        {
           if (this.listaVetor[i] == null)
           {
              this.listaVetor[i] = lig;  
              break;
           }
        }
        
        
    }
    
    public void adicionarLigacaoArray(Ligacao lig)
    {
        this.listaArray.add(lig);
    }

}
