
public class Tempo
{
    private int hora;
    private int minuto;
    private int segundo;
    
    public Tempo(int hora, int minuto, int segundo)
    {
        this.hora = hora;
        this.minuto = minuto;
        this.segundo = segundo;
    }

    public int convertSeg()
    {
        return this.hora*3600 + this.minuto*60 + this.segundo;
    }
    
    public static int difSegundos(Tempo hrIni, Tempo hrFim)
    {
       return hrFim.convertSeg() - hrIni.convertSeg();  
    }
    
    public static int difMinuto(Tempo hrIni, Tempo hrFim)
    {
       int totalSeg = Tempo.difSegundos(hrIni, hrFim);
       int totalMin = totalSeg/60;
       int resto = totalSeg%60;
       if (resto > 0)
         totalMin++;
       
       return totalMin;
    }
}
