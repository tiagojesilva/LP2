
/**
 * Escreva a descrição da classe Ligacao aqui.
 * 
 * @author (seu nome) 
 * @version (número de versão ou data)
 */
public class Ligacao
{
    private int nrOrigem;
    private String nmOrigem;
    
    private int nrDestino;
    private String nmDestino;
    
    private double valorMinuto = 1.0;
    
    private Tempo horaInicio;
    private Tempo horaFim;
    
    public Ligacao(Tempo horaInicio, int nrOrigem, String nmOrigem, int nrDestino, String nmDestino)
    {
        this.horaInicio = horaInicio;
        this.nrOrigem = nrOrigem;
        this.nmOrigem = nmOrigem;
        this.nrDestino = nrDestino;
        this.nmDestino = nmDestino;
    }
    
    public void EncerrarLigacao(Tempo horaFim)
    {
       this.horaFim = horaFim;   
    }

    public double calcValorTotal(){
        if (this.horaFim != null)
        {
           int tempogastoMinutos = Tempo.difMinuto(this.horaInicio, this.horaFim);
           double valorTotal = tempogastoMinutos * this.valorMinuto;
           return valorTotal;
        }
        else
        {
           System.out.println("Ligação não finalizada");
           return -1.0;
        }
        
    }
    
    public boolean checkNumero(int numero){
       if (numero == nrOrigem || numero == nrDestino)
         return true;
       else return false;  
        
    }
    
    
}
